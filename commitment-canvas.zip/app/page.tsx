"use client"

import { useState } from "react"
import { Dashboard } from "@/components/dashboard"
import { LessonFlow } from "@/components/lesson-flow"
import { Leaderboard } from "@/components/leaderboard"
import { Community } from "@/components/community"
import { NavigationBar } from "@/components/navigation-bar"
import { Onboarding } from "@/components/onboarding"

type Screen = "dashboard" | "lesson" | "leaderboard" | "community"

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("dashboard")
  const [lessonId, setLessonId] = useState(0)
  const [showOnboarding, setShowOnboarding] = useState(true)

  const handleStartLesson = (id: number) => {
    setLessonId(id)
    setCurrentScreen("lesson")
  }

  const handleBackToDashboard = () => {
    setCurrentScreen("dashboard")
  }

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen)
  }

  if (showOnboarding) {
    return <Onboarding onComplete={() => setShowOnboarding(false)} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95">
      <NavigationBar currentScreen={currentScreen} onNavigate={handleNavigate} />

      <div className="pt-16">
        {currentScreen === "dashboard" && <Dashboard onStartLesson={handleStartLesson} />}
        {currentScreen === "lesson" && <LessonFlow lessonId={lessonId} onBack={handleBackToDashboard} />}
        {currentScreen === "leaderboard" && <Leaderboard />}
        {currentScreen === "community" && <Community />}
      </div>
    </div>
  )
}
